import React, { useState } from "react";
import "./styles.css";

const emojiDictionary = {
  "😉": "Winking Face",
  "😊 ": "Smiling Face",
  "😘": "Face Blowing a Kiss",
  "😋": "Face Savoring Food",
  "😛": "Face with Tongue",
  "🤐": "Zipper-Mouth Face",
  "😔": "Pensive Face",
  "💔": "Broken Heart",
  "❤️": "Red Heart"
};
var emojisWeKnow = Object.keys(emojiDictionary);
export default function App() {
  const [meaning, setMeaning] = useState("");

  function emojiInputHandler(event) {
    var userInput = event.target.value;

    var meaning = emojiDictionary[userInput];
    setMeaning(meaning);

    if (meaning === undefined) {
      setMeaning("The emoji you asked for is not available in our database");
    }
  }
  function emojiClickHandler(emoji) {
    var meaning = emojiDictionary[emoji];
    setMeaning(meaning);
  }

  return (
    <div className="App">
      <h1>inside outt!!</h1>

      <input onChange={emojiInputHandler}></input>
      <h2>{meaning}</h2>
      <h3>emojis we have</h3>
      {emojisWeKnow.map(function (emoji) {
        return (
          <span
            onClick={() => emojiClickHandler(emoji)}
            style={{ fontSize: "2rem", padding: "0.5rem", cursor: "pointer" }}
            key={emoji}
          >
            {emoji}
          </span>
        );
      })}
    </div>
  );
}

//VISTER: View--->Interact--->State in event handler--->Render
